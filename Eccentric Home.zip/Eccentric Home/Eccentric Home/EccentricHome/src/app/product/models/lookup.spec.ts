import { Lookup } from './lookup';

describe('Lookup', () => {
  it('should create an instance', () => {
    expect(new Lookup()).toBeTruthy();
  });
});
