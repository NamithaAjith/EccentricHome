import { Lookup } from './lookup';
export interface IProduct{
    id:number;
    name:string;
    code:string;
    category:Lookup;
   workingtime:Lookup
    contact:number;
    AverageRate:number
}
export class Product {
    id:number;
    name:string;
    code:string;
    category:Lookup;
    workingtime:Lookup
    contact:number;
    AverageRate:number
    constructor(name?:string,code?:string,category?:Lookup,workingtime?:Lookup,contact?:number, AverageRate?:number){
        this.name = name;
        this.code = code;
        this.category = category;
        this.workingtime= workingtime;
        this.contact = contact;
        this.AverageRate = AverageRate;
    }
}


