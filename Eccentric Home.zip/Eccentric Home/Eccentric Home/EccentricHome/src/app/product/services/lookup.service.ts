import { Injectable } from '@angular/core';
import { Lookup } from '../models/lookup';
import { of, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LookupService {

  private units:Array<Lookup> =  [
    { name: 'Fulltime', code:'ID/m', category:'InteriorDesigner' },
    { name: 'Daytime', code:'ID/m', category:'InteriorDesigner' },
    { name: 'Weekdays', code:'ID/m', category:'InteriorDesigner' },
    { name: 'Weekends', code:'ID/m', category:'InteriorDesigner' },
    
];
private productCategories:Array<Lookup> =  [
  { name: 'Modularkitchen', code:'ID/m', category:'InteriorDesigner' },
  { name: 'Modularkitchen', code:'ID/m', category:'InteriorDesigner' },
  { name: 'Modularkitchen', code:'ID/m', category:'InteriorDesigner' },
  { name: 'Modularkitchen', code:'ID/m', category:'InteriorDesigner' },
  
];

  constructor() { }
  getProductCategories():Observable<Lookup[]>{
    return of(this.productCategories);
  }

  getUnits():Observable<Lookup[]>{
    return of(this.workingtime);
    
  }

}
