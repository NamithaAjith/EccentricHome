import { Injectable } from '@angular/core';
import { Product, IProduct } from '../models/product';
import { of, Observable } from 'rxjs';
import { max } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private products:Array<Product> =  [
    {  id:1, name: 'Modular Kitchen', code: 'ID/m', 
    category: { name: 'Fulltime', code:'ID/m', category:'InteriorDesigner' },workingtime : { name: 'Full', code:'ID/m', category:'InteriorDesigner' }, contact: 9900000001, AverageRate: 55000 },
    {  id:2, name: 'Modular Kitchen', code: 'ID/m',
     category: { name: 'InteriorDesigner', code: '1', category: 'InteriorDesigner1' }, workingtime : { name: 'InteriorDesigner', code: '1', category: 'InteriorDesigner1' }, contact: 9000000011, AverageRate: 110000 },
    {  id:3, name: 'Modular Kitchen', code: 'ID/m', 
    category: { name: 'Daytime', code:'ID/m', category:'InteriorDesigner' }, workingtime :{ name: 'Daytime', code:'ID/m', category:'InteriorDesigner' }, contact: 8000000012, AverageRate: 100000 },
    {  id:4, name: 'Painting', code: 'ID/p', 
    category: { name: 'Daytime', code:'ID/m', category:'InteriorDesigner' }, workingtime : { name: 'Daytime', code:'ID/m', category:'InteriorDesigner' }, contact: 8000000401, AverageRate: 110  },
    {  id:5, name: 'Painting', code: 'ID/p',
     category:{ name: 'Daytime', code:'ID/m', category:'InteriorDesigner' }, workingtime : { name: 'Daytime', code:'ID/m', category:'InteriorDesigner' }, contact: 9000030001, AverageRate: 110  },
    {  id:6, name: 'Flooring', code: 'ID/f',
     category: { name: 'Daytime', code:'ID/m', category:'InteriorDesigner' },workingtime :  { name: 'Daytime', code:'ID/m', category:'InteriorDesigner' }, contact: 8000030001, AverageRate: 110  },
    {  id:7, name: 'Flooring', code: 'ID/f', 
    category:{ name: 'Weekdays', code:'ID/m', category:'InteriorDesigner' }, workingtime : { name: 'Weekdays', code:'ID/m', category:'InteriorDesigner' },contact: 8000220001 ,AverageRate: 110  },
    {  id:8, name: 'Dog', code: 'Pt/d', 
    category: { name: 'Fulltime', code:'ID/m', category:'Pets' },workingtime : { name: 'Fulltime', code:'ID/m', category:'Pets' }, contact: 8000730001, AverageRate: 110  },
    {  id:9, name: 'Cat', code: 'Pt/c',
     category:{ name: 'Weekdays', code:'ID/m',  category:'Pets' }, workingtime :{ name: 'Weekdays', code:'ID/m',  category:'Pets' }, contact: 8320030001, AverageRate: 110  },
    {  id:10, name: 'Petfood', code: 'Pt/f',
     category: { name: 'Weekends', code:'ID/m', category:'Pets' }, workingtime : { name: 'Weekends', code:'ID/m', category:'Pets' }, contact: 8008830001, AverageRate: 110  },
    {  id:11, name: 'Driver', code: 'ser/d', 
    category: { name: 'Weekends', code:'ID/m',category:'Pets' }, workingtime : { name: 'Weekends', code:'ID/m',category:'Pets' }, contact: 8096030001, AverageRate: 110 },
    {  id:12, name: 'Driver', code: 'ser/d',
     category: { name: 'Fulltime', code:'ID/m', category:'ServiceProvider' }, workingtime :{ name: 'Fulltime', code:'ID/m', category:'ServiceProvider' }, contact: 8003000185, AverageRate: 110  },
    {  id:13, name: 'Electrician', code: 'ser/e', 
    category: { name: 'Fulltime', code:'ID/m', category:'ServiceProvider' }, workingtime : { name: 'Fulltime', code:'ID/m', category:'ServiceProvider' }, contact: 8002230001, AverageRate: 110  },
    {  id:14, name: 'Electrician', code: 'ser/e', 
    category:{ name: 'Fulltime', code:'ID/m', category:'ServiceProvider' }, workingtime :{ name: 'Fulltime', code:'ID/m', category:'ServiceProvider' }, contact: 8055030001, AverageRate: 110  },
    {  id:15, name: 'cook', code: 'ser/c',
     category: { name: 'Fulltime', code:'ID/m', category:'ServiceProvider' }, workingtime : { name: 'Fulltime', code:'ID/m', category:'ServiceProvider' }, contact: 8900030021, AverageRate: 110  },
    {  id:16, name: 'cook', code: 'ser/c', 
    category: { name: 'Weekends', code:'ID/m', category:'ServiceProvider' }, workingtime :{ name: 'Weekends', code:'ID/m', category:'ServiceProvider' },contact: 8002210001, AverageRate: 110 },
    {  id:17, name: 'Plumber', code: 'ser/p', 
    category:{ name: 'Weekdays', code:'ID/m', category:'ServiceProvider' }, workingtime : { name: 'Weekdays', code:'ID/m', category:'ServiceProvider' }, contact: 8780030001, AverageRate: 110  },
    {  id:18, name: 'Plumber', code: 'ser/p', 
    category:{ name: 'Weekends', code:'ID/m', category:'ServiceProvider' }, workingtime :{ name: 'Weekends', code:'ID/m', category:'ServiceProvider' }, contact: 8230330001, AverageRate: 110  },
    {  id:19, name: 'Plumber', code: 'ser/p',
     category:{ name: 'Weekdays', code:'ID/m', category:'ServiceProvider' }, workingtime : { name: 'Weekdays', code:'ID/m', category:'ServiceProvider' }, contact: 8580030001, AverageRate: 110  },
    {  id:20, name: 'Carpenter', code: 'ser/c', 
    category:{ name: 'Weekdays', code:'ID/m', category:'ServiceProvider' },workingtime : { name: 'Weekdays', code:'ID/m', category:'ServiceProvider' }, contact: 8213030001,AverageRate: 110  },
    {  id:21, name: 'Carpenter', code: 'ser/c', 
    category: { name: 'Weekends', code:'ID/m', category:'ServiceProvider' }, workingtime : { name: 'Weekends', code:'ID/m', category:'ServiceProvider' }, contact: 8321030001, AverageRate: 110 },
    {  id:22, name: 'Carpenter', code: 'ser/c',
     category: { name: 'Weekdays', code:'ID/m', category:'ServiceProvider' }, workingtime: { name: 'Weekdays', code:'ID/m', category:'ServiceProvider' }, contact: 8120030001, AverageRate: 110 }
];

  constructor() { }
  getAllProducts():Observable<IProduct[]>{
    return of(this.products)
  }

  getProductById(id:number):Observable<IProduct>{
    var product = this.products.find(item => item.id === id);
    return of(product);
  }

  addNewProduct(product:IProduct):void{
    this.products.sort(item => item.id)
    product.id = this.products.length + 1
    this.products.push(product);
  }

  deleteProduct(product:IProduct):IProduct[]{
    const index = this.products.findIndex(item => item.id === product.id);
    const deletedItem = this.products.splice(index,1);

    return deletedItem;
  }

  updateProduct(product:IProduct):void{

    const index = this.products.findIndex(item => item.id === product.id);
    this.products[index] = product;
  }

}
