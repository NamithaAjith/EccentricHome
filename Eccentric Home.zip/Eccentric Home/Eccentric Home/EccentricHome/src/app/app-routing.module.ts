import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UserComponent } from './user/user.component';
import { HomeComponent } from './home/home.component';
import { AppComponent } from './app.component';



const routes: Routes = [
  // { path:'',redirectTo:'home', pathMatch:'full'},
  { path: ' ',component:HomeComponent},
  { path:'login', component:LoginComponent },
  // { path:'login',redirectTo:'login', pathMatch:'full'},
  { path: 'register', component:RegisterComponent},
  { path:'user', component:UserComponent },
  { path:'product',redirectTo :'/products',pathMatch:'full'},
  {path:'products', loadChildren:'./product/product.module#ProductModule'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
