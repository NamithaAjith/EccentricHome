const mongoose = require ('mongoose');
const Schema = mongoose.Schema;
const bcrypt = require('bcrypt');

const schema = new Schema ({
    fname : {type:String,require:true},
    lname : {type:String,require:true},
    email : {type:String,require:true},
    password : {type:String,require:true},
    phnum: {type:Number,require:true},
    creation_dt : {type:Date,require:true},
});

schema.statics.hashPassword = function hashPassword(Password){
    return bcrypt.hashSync (password,10);
}
schema.methods.isValid= function (hashedPassword){
    return bcrypt.compareSync (hashedpassword,this.password);
}
module.exports = mongoose.model('User',schema);