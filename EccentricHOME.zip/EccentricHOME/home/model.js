var mongoose = require('mongoose');
 
var pdtSchema = new mongoose.Schema({
    name : String,
    category: String,
    service: String,
    phone: Number,
    email: String

});
var Product = module.exports = mongoose.model('Product', pdtSchema);

module.exports.getProducts = function(callback){
// console.log('my work');
        Product.find(callback);
}
module.exports.addProduct = function(newProduct, callback){
            Product.create(newProduct,callback);
}
module.exports.updateProduct = function(id,newProduct,callback){
    Product.findByIdAndUpdate(id,newProduct,callback);
}
module.exports.deleteProduct = function(id,callback){
    Product.findByIdAndRemove(id,callback);
}
module.exports.getProduct = function(id,callback){
    Product.findById(id,callback);
}