var express = require('express');
var router = express.Router();
var Product = require('./model');

router.get('/',function(req , res){
    Product.getProducts(function(err,products){
        if(err) throw err;
        res.json(products);
    });
    // res.send("hello from the router..");

});

router.post('/',function(req,res){i6
    var newProduct = {
        name : req.body.name,
        category:req.body.category,
        service: req.body.service,
        phone: req.body.phone,
        email: req.body.email
    }
    Product.addProduct(newProduct, function(err,product){
        if(err) throw err;
        res.json(product);
    });

});
router.put('/:_id',function(req,res){
    var update = {
        name : req.body.name,
        category:req.body.category,
        service: req.body.service,
        phone: req.body.phone,
        email: req.body.email
    }
    Product.updateProduct(req.params._id,update, function(err,product){
        if(err) throw err;
        res.json(product);
    });

});
router.delete('/:_id',function(req,res){
    
    Product.deleteProduct(req.params._id, function(err,product){
        if(err) throw err;
        res.json(product);
    });

});
router.get('/:_id',function(req,res){
    
    Product.getProduct(req.params._id,function(err,product){
        if(err) throw err;
        res.json(product);
    });

});


module.exports = router;
 