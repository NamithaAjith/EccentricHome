var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');

mongoose.connect("mongodb://localhost:27017/products" );
    // console.log("successfully connected to" + config );
// mongoose.connect(config)
//     .connection
//         .on('connected',function(){
//             console.log("successfully connected to " + config)
//         }) 
//         .on('error',function(err){
//         console.log("database error" + err);
//     });

// const bodyParser = require('body-parser');
// const { urlencoded } = require('body-parser');
mongoose.set('useFindAndModify', false);


var app = express();
var port = 3000;
app.get('/' , function(req,res){
    res.send("hello!!!");
});

var router = require('./routes');
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.use('/api/products',router);
app.listen(port,function(){
    console.log("server is running on port" + port);
});

