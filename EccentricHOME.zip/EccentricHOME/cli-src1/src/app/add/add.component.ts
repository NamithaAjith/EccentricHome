import { Component, OnInit } from '@angular/core';
import { PdtService } from '../pdt.service'
import { Product } from '../product';

import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  constructor(
    public pdtService:PdtService,
    public route:ActivatedRoute,
    public router:Router
  ) { }

  ngOnInit(): void {
  }
  model = new Product();
  addProduct(){
    this.pdtService.addProduct(this.model)
        .subscribe(()=> this.goBack())
  }
   goBack(){
    this.router.navigate(['/home'])
  }

}
