import { Component, OnInit } from '@angular/core';
import { PdtService } from '../pdt.service'
import { Product } from '../product';

import { ActivatedRoute, Params, Router } from '@angular/router';


@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  constructor(
    public pdtService:PdtService,
    public route:ActivatedRoute,
    public router:Router
 ) { }

 ngOnInit() {
   this.getProduct();
 }
 model = new Product();
  id = this.route.snapshot.params['id'];
  
  getProduct(){
    this.pdtService.getProduct(this.id)
        .subscribe(product=>{
          this.model = product;
        })
  }

  updateEmployee(){
    this.pdtService.updateProduct(this.id,this.model)
        .subscribe(()=> this.goBack())
  }

   goBack(){
    this.router.navigate(['/home'])
  }

  
}
