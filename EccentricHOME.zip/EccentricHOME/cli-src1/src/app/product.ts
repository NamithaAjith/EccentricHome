export class Product {
    name : String;
    category: String;
    service: String;
    phone: Number;
    email: String
}