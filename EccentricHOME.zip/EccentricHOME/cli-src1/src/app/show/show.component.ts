import { Component, OnInit } from '@angular/core';
import { PdtService } from '../pdt.service'
import { Product } from '../product';

import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {

  constructor(public pdtService:PdtService,
    public route:ActivatedRoute,
    public router:Router
 ) { }

 ngOnInit() {
   this.getProduct();
 }

 product:Product;
 getProduct(){
   var id = this.route.snapshot.params['id'];
   this.pdtService.getProduct(id)
       .subscribe(product=>{
         this.product = product;
       })
 }
 goBack(){
   this.router.navigate(['/home'])
 }
}

